const express = require('express');

const livro = require('../model/Usuario');

const router = express.Router();

router.post('/livro/cadastrarUsuario', (req, res)=>{

    const { idCdastro, nome, sobrenome, email, celular } = req.body;

    usuario.create({
        idCdastro, 
        descricao,
        imagem : 'TESTE DE IAGEM DE LIVRO',
        tblUsuarioCodUsuario
    }).then(
        ()=>{
            res.status(200).json({"MSG": "USUARIO INSERIDO COM SUCESSO!"});
        }
    );

});



module.exports = router;